from erori.exceptii import RepositoryError

class RepoStudenti:

    def __init__(self):
        self.__studenti = []

    def __len__(self):
        """
        Functie care returneaza lungimea listei de studenti
        """
        return len(self.__studenti)

    def adauga_student(self, stud):
        """
        Functie care adauga in lista de studenti studentul stud
        :param stud: studentul care e format de un id si un nume
        """
        for _stud in self.__studenti:
            if _stud == stud:
                raise RepositoryError("id existent!")
        self.__studenti.append(stud)

    def exist_with_id(self,id):
        for stud in self.__studenti:
            if stud.get_id_stud() == id:
                return True
        return False

    def cauta_dupa_id(self, id_stud):
        """
        Functie care returneaza un student cautat in functie de id-ul id_stud
        :param id_stud: id-ul dupa care gasim studentul dorit
        """
        ok = True
        for _stud in self.__studenti:
            if _stud.get_id_stud() == id_stud:
                return _stud
        if ok:
            raise RepositoryError("id inexistent!")

    def cauta_dupa_nume(self, nume):
        """
        Functie care cauta un student dupa numele nume
        :param nume: nume dupa care cautam un student
        """
        ok = True
        for _stud in self.__studenti:
            if _stud.get_nume() == nume:
                return _stud
        if ok:
            raise RepositoryError("nume inexistent!")

    def sterge_student(self, id_stud):
        """
        Functie care sterge un student din lista de studenti, daca exista
        :param id_stud: id-ul dupa care ne ghidam ce student sa stegrem
        """
        student = self.cauta_dupa_id(id_stud)
        self.__studenti.remove(student)

    def modifica_stud(self, id_stud ,nume):
        """
        Functie care modifica ekementele unui student
        :param id_stud: id-ul studentului
        :param nume: numele nou al studentului
        """
        student = self.cauta_dupa_id(id_stud)
        student.set_nume(nume)


    def get_all_studs(self):
        """
        Functie care returneaza lista cu toti studentii
        """
        return self.__studenti[:]


class RepoDiscipline:

    def __init__(self):
        self.__discipline = []

    def __len__(self):
        """
        Functie care returneaza lungimea listei de discipline
        """
        return len(self.__discipline)

    def adauga_disciplina(self, disc):
        """
        Functie care adauga in lista de discipline o disciplina
        :param disc: disciplina pe care o adaugam
        """
        for _disc in self.__discipline:
            if _disc == disc:
                raise RepositoryError("id existent!")
        self.__discipline.append(disc)

    def sterge_disciplina(self, id_disc):
        """
        Functie care sterge din lista de discipline disciplina determinata de id_disc
        :param id_disc: id-ul disciplinei pe care dorim sa o stergem din lista
        """
        disciplina = self.cauta_dupa_id(id_disc)
        self.__discipline.remove(disciplina)

    def modifica_disciplina(self, id_disc, nume, profesor):
        """
        Fuctie care modifica elementele unei discipline
        :param id_disc: id-ul disciplinei dorite
        :param nume: noul nume al disciplinei
        :param profesor: noul profesor al disciplinei
        """
        disciplina = self.cauta_dupa_id(id_disc)
        disciplina.set_nume(nume)
        disciplina.set_profesor(profesor)

    def cauta_dupa_id(self, id_disciplina):
        """
        Functie care cauta dupa id-ul id_disciplina o disciplina
        :param id_disciplina: id-ul dupa care cautam disciplina
        """
        ok = True
        for _disc in self.__discipline:
            if _disc.get_id_disc() == id_disciplina:
                return _disc
        if ok:
            raise RepositoryError("id inexistent!")

    def cauta_dupa_nume(self, nume):
        """
        Functie care cauta dupa numele nume o disciplina
        :param nume: numele dupa care cautam disciplina
        """
        ok = True
        for _disc in self.__discipline:
            if _disc.get_nume() == nume:
                return _disc
        if ok:
            raise RepositoryError("nume inexistent!")

    def cauta_dupa_profesor(self, profesor):
        """
        Functie care cauta dupa profesorul profesor o disciplina
        :param profesor: profesorul dupa care cautam disciplina
        """
        ok = True
        for _disc in self.__discipline:
            if _disc.get_profesor() == profesor:
                return _disc
        if ok:
            raise RepositoryError("profesor inexistent!")


    def get_all_discipline(self):
        """
        Functie care returneaza lista cu toate disciplinele
        """
        return self.__discipline[:]

class RepoNote():
    def __init__(self):
        self.__note = []

    def __len__(self):
        """
        Functie care returneaza lungimea listei de discipline
        """
        return len(self.__note)

    def get_all(self):
        return self.__note[:]

    def adauga_nota_repo(self, nota):
        """
        Functie care adauga in lista de note o nota
        :param nota: nota pe care o adaugam
        """
        for x in self.__note:
            if x == nota:
                raise RepositoryError("id existent!")
        self.__note.append(nota)

    def sort_by_name(self):
        """
        Functie care sorteaza crescator lista de note in functie de numele studentilor
        :return: lista de note sortata crescator dupa nume
        """
        for i in range(0, len(self.__note) - 1):
            name1 = str(self.__note[i].get_stud().get_nume())
            for j in range(i + 1, len(self.__note)):
                name2 = str( self.__note[j].get_stud().get_nume())
                if name1 > name2:
                    self.__note[i], self.__note[j] = self.__note[j], self.__note[i]

    def sort_by_val_notes(self):
        """
        Functie care sorteaza crescator lista de note in functie de notele studentilor
        :return: lista de note sortata crescator dupa valoarea notelor
        """
        for i in range(0, len(self.__note) - 1):
            val_nota1 = float( self.__note[i].get_val_nota())
            for j in range(i + 1, len(self.__note)):
                val_nota2 = float( self.__note[j].get_val_nota())
                if val_nota1 > val_nota2:
                    self.__note[i], self.__note[j] = self.__note[j], self.__note[i]

    def sort_by_medii_20(self):
        copy_list = self.__note[:]

        for i in range(0, len(copy_list) - 1):
            val_nota1 = float( copy_list[i].get_val_nota())
            for j in range(i + 1, len(copy_list)):
                val_nota2 = float( copy_list[j].get_val_nota())
                if val_nota1 < val_nota2:
                    copy_list[i], copy_list[j] = copy_list[j], copy_list[i]

        n = len(copy_list)
        n = n/5 + 1

        return copy_list[:n]