class ValidationError(Exception):
    pass

class RepositoryError(Exception):
    pass
