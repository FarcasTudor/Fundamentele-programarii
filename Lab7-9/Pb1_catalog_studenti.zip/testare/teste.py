from domain.entitati import Student,Disciplina
from validare.validatori import ValidatorStudent,ValidatorDisciplina
from erori.exceptii import ValidationError,RepositoryError
from infrastructura.repozitorii import RepoStudenti,RepoDiscipline
from business.servicii import ServiceStudenti,ServiceDiscipline


class Teste:

    def __test_creeaza_student(self):
        """
        Functie de test care verifica daca un student este creat cu succes
        """
        id_stud = 12
        nume = "Andrei"
        stud = Student(id_stud, nume)
        assert(stud.get_id_stud() == id_stud)
        assert(stud.get_nume() == nume)
        assert(str(stud) == "[12]Andrei")
        assert(stud.__str__() == "[12]Andrei")

    def __test_valideaza_student(self):
        """
        Functie de test care verifica daca un student este valid
        Cuprinde atat cazuri in care studentul este valid, cat si daca avem un id invalid sau nume invalid, cauzuri in care vom vea erori
        """
        id_stud = 12
        nume = "Andrei"
        stud = Student(id_stud, nume)
        valid = ValidatorStudent()
        valid.valideaza(stud)

        inv_id_stud = -23
        inv_nume = ""
        stud_inv_id = Student(inv_id_stud, nume)
        stud_inv = Student(inv_id_stud, inv_nume)
        try:
            valid.valideaza(stud_inv_id)
            assert(False)
        except ValidationError as ve:
            assert(str(ve) == "id invalid!\n")

        try:
            valid.valideaza(stud_inv)
            assert(False)
        except ValidationError as ve:
            assert(str(ve) == "id invalid!\nnume invalid!\n")

    def __test_adauga_student_repo(self):
        """
        Functie de test care verifica daca un student se adauga cu succes in lista de studenti
        Cuprinde si cazuri in care daca de exista un student si dorim sa introducem un student nou cu acelasi id, sa verifice ca nu se introduce al doilea student, deoarece fiecare student are un id unic
        """
        repo = RepoStudenti()
        assert(len(repo) == 0)
        assert(repo.__len__() == 0)

        id_stud = 12
        nume = "Andrei"
        stud = Student(id_stud, nume)
        repo.adauga_student(stud)
        assert (len(repo) == 1)
        stud_gasit = repo.cauta_dupa_id(id_stud)
        assert(stud_gasit == stud)
        assert (stud_gasit.get_nume() == stud.get_nume())

        all = repo.get_all_studs()
        assert(len(all) == 1)
        assert (all[0] == stud)
        assert (all[0].get_nume() == stud.get_nume())

        id_stud_inexist = 24
        try:
            repo.cauta_dupa_id(id_stud_inexist)
            assert(False)
        except RepositoryError as re:
            assert(str(re) == "id inexistent!")

        alt_nume = "George"
        alt_stud_same_id = Student(id_stud, alt_nume)
        try:
            repo.adauga_student(alt_stud_same_id)
            assert(False)
        except RepositoryError as re:
            assert(str(re) == "id existent!")

    def __test_adauga_student_service(self):
        """
        Functie de test care verifica daca se adauga cu succes un student in clasa ServiceStudent
        """
        repo = RepoStudenti()
        valid = ValidatorStudent()
        srv = ServiceStudenti(valid, repo)
        id_stud = 12
        nume = "Andrei"
        assert (srv.get_nr_studenti() == 0)
        srv.adauga_student(id_stud, nume)
        assert (srv.get_nr_studenti() == 1)
        alt_nume = "Gabi"
        try:
            srv.adauga_student(id_stud, alt_nume)
            assert (False)
        except RepositoryError as re:
            assert (str(re) == "id existent!")

        inv_id_stud = -23
        inv_nume = ""
        try:
            srv.adauga_student(inv_id_stud, inv_nume)
            assert (False)
        except ValidationError as ve:
            assert (str(ve) == "id invalid!\nnume invalid!\n")

    def __test_sterge_student(self):
        """
        Functie de test care verifica daca un student se sterge cu succes din lista de studenti
        """
        id_stud = 4
        nume = "CasaBlanca"
        stud = Student(id_stud, nume)
        repo = RepoStudenti()
        repo.adauga_student(stud)
        assert(len(repo) == 1)
        repo.sterge_student(id_stud)
        assert(len(repo) == 0)

    def __test_modifica_student(self):
        """
        Functie de test care verifica daca un student isi modifica cu succes numele
        """
        id_stud = 4
        nume = "Ioan"
        stud = Student(id_stud, nume)
        repo = RepoStudenti()
        repo.adauga_student(stud)
        repo.modifica_stud(id_stud, "Gabriel")
        assert(stud.get_nume() == "Gabriel")

    def __test_creeaza_disciplina(self):
        """
        Functie de test care verifica daca o disciplina se creeaza cu succes
        """
        id_disciplina = 13
        nume = "Informatica"
        profesor = "Gabitza"
        disc = Disciplina( id_disciplina, nume, profesor )
        assert (disc.get_id_disc() == id_disciplina)
        assert (disc.get_nume() == nume)
        assert (str(disc) == "[13]Informatica -> Gabitza")
        assert (disc.__str__() == "[13]Informatica -> Gabitza")

    def __test_valideaza_disciplina(self):
        """
        Functie de test care verifica daca o disciplina este valida
        Cuprinde si cazuri in care se introduc date gresite la id, nume sau profesor
        """
        id_disciplina = 13
        nume = "Informatica"
        profesor = "Gabitza"
        disc = Disciplina(id_disciplina, nume, profesor)
        valid = ValidatorDisciplina()
        valid.valideaza(disc)

        inv_id_disc = -23
        inv_nume = ""
        profesor = "Gabi"
        inv_profesor = ""
        disc_inv_id = Disciplina(inv_id_disc, nume, profesor)
        disc_inv = Disciplina(inv_id_disc, inv_nume, inv_profesor )
        try:
            valid.valideaza(disc_inv_id)
            assert(False)
        except ValidationError as ve:
            assert(str(ve) == "id invalid!\n")

        try:
            valid.valideaza(disc_inv)
            assert(False)
        except ValidationError as ve:
            assert(str(ve) == "id invalid!\nnume invalid!\nprofesor invalid!\n")

    def __test_adauga_disciplina_repo(self):
        """
        Functie de test care verifica daca se adauga cu succes o disciplina in lista de discipline
        """

        repo = RepoDiscipline()
        assert(len(repo) == 0)
        assert(repo.__len__() == 0)
        id_disciplina = 13
        nume = "Informatica"
        profesor = "Gabitza"
        disc = Disciplina(id_disciplina, nume, profesor)
        repo.adauga_disciplina(disc)
        assert (len(repo) == 1)
        assert (repo.__len__() == 1)
        disc_gasit = repo.cauta_dupa_id(id_disciplina)
        assert(disc_gasit == disc)
        assert(disc_gasit.get_nume() == disc.get_nume())
        assert(disc_gasit.get_profesor() == disc.get_profesor())
        all = repo.get_all_discipline()
        assert(len(all) == 1)
        assert(all[0] == disc)
        assert(all[0].get_nume() == disc.get_nume())
        assert(all[0].get_profesor() == disc.get_profesor())
        id_disc_inexist = 24
        try:
            repo.cauta_dupa_id(id_disc_inexist)
            assert(False)
        except RepositoryError as re:
            assert(str(re) == "id inexistent!")

    def __test_adauga_disciplina_service(self):
        """
        Functie de test care verifica daca se adauga cu succes o disciplina in clasa ServiceDiscipline
        """
        repo = RepoDiscipline()
        valid = ValidatorDisciplina()
        srv = ServiceDiscipline(valid, repo)
        id_disc = 12
        nume = "Info"
        profesor = "Ioan"
        assert (srv.get_nr_disc() == 0)
        srv.adauga_disc(id_disc, nume, profesor)
        assert (srv.get_nr_disc() == 1)
        alt_nume = "Mate"
        try:
            srv.adauga_disc(id_disc, alt_nume, profesor)
            assert (False)
        except RepositoryError as re:
            assert (str(re) == "id existent!")

        inv_id_disc = -23
        inv_nume = ""
        try:
            srv.adauga_disc(inv_id_disc, inv_nume, profesor)
            assert (False)
        except ValidationError as ve:
            assert (str(ve) == "id invalid!\nnume invalid!\n")

    def __test_sterge_disciplina(self):
        """
        Functie de test care verifica daca se sterge cu succes o disciplina din lista de discipline
        """
        id_disc = 4
        nume = "ASC"
        profesor = "Vancea"
        disc = Disciplina(id_disc, nume, profesor)
        repo = RepoDiscipline()
        repo.adauga_disciplina(disc)
        assert (len(repo) == 1)
        repo.sterge_disciplina(id_disc)
        assert (len(repo) == 0)

    def __test_modifica_disciplina(self):
        """
        Functie de test care verifica daca se modifica cu succes numele si profesorul unei discipline
        """
        id_disc= 4
        nume = "Info"
        profesor = "Ildiko"
        disc = Disciplina(id_disc, nume, profesor)
        repo = RepoDiscipline()
        repo.adauga_disciplina(disc)
        repo.modifica_disciplina(id_disc, "Matematica", "Marcel")
        assert(disc.get_nume() == "Matematica")
        assert(disc.get_profesor() == "Marcel")


    def run_all_tests(self):
        """
        Aceasta functie se ocupa de testarea tuturor functiilor de test a programului
        """
        #Teste pentru studenti
        self.__test_creeaza_student()
        self.__test_valideaza_student()
        self.__test_adauga_student_repo()
        self.__test_adauga_student_service()
        self.__test_sterge_student()
        self.__test_modifica_student()
        #Teste pentru discipline
        self.__test_creeaza_disciplina()
        self.__test_valideaza_disciplina()
        self.__test_adauga_disciplina_repo()
        self.__test_adauga_disciplina_service()
        self.__test_sterge_disciplina()
        self.__test_modifica_disciplina()

