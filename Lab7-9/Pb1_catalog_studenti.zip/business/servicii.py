from domain.entitati import Student, Disciplina
from domain. DTOs import DiscStudDTO,  NoteDTO

class ServiceStudenti:

    def __init__(self, valid_student, repo_studenti):
        self.__valid_student = valid_student
        self.__repo_studenti = repo_studenti

    def get_all_studenti(self):
        """
        Functie care va returna toti studentii
        """
        return self.__repo_studenti.get_all_studs()

    def exist_with_id(self,id_stud):
        return self.__repo_studenti.exist_with_id(id_stud)


    def get_nr_studenti(self):
        """
        Functie care returneaza lungimea listei de studenti
        """
        return len(self.__repo_studenti)

    def sterg_student(self, id_stud):
        """
        Functie care ajuta la stergerea unui student cu id-ul id_stud din lista de studenti
        :param id_stud: id-ul dupa care stergem studentul
        """
        self.__repo_studenti.sterge_student(id_stud)

    def adauga_student(self, id_stud, nume):
        """
        Functie care va apela o functie din repozitorii pentru a adauga un student in lista de studenti
        :param id_stud: id-ul studentului
        :param nume: numele studentului
        """
        student = Student(id_stud, nume)
        self.__valid_student.valideaza(student)
        self.__repo_studenti.adauga_student(student)

    def modifica_student(self, id_stud, nume):
        """
        Functie care modifica numele unui student determinat de id_stud
        :param id_stud: id-ul studentului
        :param nume: numele nou al studentului
        """
        self.__repo_studenti.modifica_stud(id_stud, nume)

    def gaseste_stud_dupa_id(self, id_stud):
        """
        Functie care gaseste un student dupa  id-ul id_stud
        :param id_stud: id-ul dupa care gasim un student
        """
        student = self.__repo_studenti.cauta_dupa_id(id_stud)
        return student

    def gaseste_stud_dupa_nume(self, nume):
        """
        Functie care gaseste un student dupa numele nume
        :param nume: numele dupa care gasim un student
        :return:
        """
        student = self.__repo_studenti.cauta_dupa_nume(nume)
        return student



class ServiceDiscipline:

    def __init__(self, valid_disciplina, repo_discipline):
        self.__valid_disciplina = valid_disciplina
        self.__repo_discipline = repo_discipline

    def get_all_disc(self):
        """
        Functie care returneaza toate disciplinele
        """
        return self.__repo_discipline.get_all_discipline()

    def get_nr_disc(self):
        """
        Functie care returneaza numarul de discipline din lista de discipline
        """
        return len(self.__repo_discipline)

    def adauga_disc(self, id_disc, nume, profesor):
        """
        Functie care creaza o disciplina prin intermediul id-ului id_disc, numelui nume si profesorul profesor
        :param id_disc: id-ul disciplinei
        :param nume: numele disciplinei
        :param profesor: profesorul disciplinei
        """
        disc = Disciplina(id_disc, nume, profesor)
        self.__valid_disciplina.valideaza(disc)
        self.__repo_discipline.adauga_disciplina(disc)

    def sterg_disciplina(self, id_disc):
        """
        Functie care apeleaza o functie din repozitorii pentru a sterge o disciplina din lista de discipline
        :param id_disc: id-ul dupa care stergem disciplina respectiva
        """

        self.__repo_discipline.sterge_disciplina(id_disc)

    def modifica_disciplina(self, id_disc, nume, profesor):
        """
        Functie care apeleaza o functie din repozitorii pentru a modifica elementele unei discipline
        :param id_disc: id-ul disciplinei e care o sa o modificam
        :param nume: noul nume al disciplinei
        :param profesor: noul profesor al disciplinei
        """
        self.__repo_discipline.modifica_disciplina(id_disc, nume, profesor)

    def gaseste_disc_dupa_id(self, id_disc):
        """
        Functie care gaseste o disciplina dupa id-ul id_disc
        :param id_disc: id-ul dupa care cautam o disciplina
        """
        disciplina = self.__repo_discipline.cauta_dupa_id(id_disc)
        return disciplina

    def gaseste_disc_dupa_nume(self, nume):
        """
        Functie care gaseste o disciplina dupa numele nume
        :param nume: numele dupa care cautam o disciplina
        """
        disciplina = self.__repo_discipline.cauta_dupa_nume(nume)
        return disciplina

    def gaseste_disc_dupa_profesor(self, profesor):
        """
        Functie care gaseste o disciplina dupa profesorul profesor
        :param profesor: profesorul dupa cautam o disciplina
        """
        disciplina = self.__repo_discipline.cauta_dupa_profesor(profesor)
        return disciplina

class ServiceNote:

    def __init__(self, valid_nota, repo_note, repo_studenti, repo_discipline ):
        self.__valid_nota = valid_nota
        self.__repo_note = repo_note
        self.__repo_studenti = repo_studenti
        self.__repo_discipline = repo_discipline

    def asignare_nota(self, id_nota, id_stud, id_disc, val_nota):
        nota = NoteDTO( id_nota, id_stud, id_disc, val_nota)
        self.__valid_nota.valideaza(nota)
        self.__repo_note.adauga_nota_repo(nota)

    def ordoneaza_note_dupa_nume(self):
        self.__repo_note.sort_by_name()

    def ordoneaza_note_dupa_val_note(self):
        self.__repo_note.sort_by_val_notes()

    def ordonare_primii_20(self):
        return self.__repo_note.sort_by_medii_20()

    def get_all_note(self):
        note_dtos = self.__repo_note.get_all()
        note = {}
        for note_dto in note_dtos:
            stud = self.__repo_studenti.cauta_dupa_id(note_dto.get_id_stud())
            disc = self.__repo_discipline.cauta_dupa_id(note_dto.get_id_disc())
            note_dto.set_stud(stud)
            note_dto.set_disc(disc)
            if disc.get_id_disc() not in note:
                note[disc.get_id_disc()] = []
            note[disc.get_id_disc()].append(note_dto)

        rezultat = []
        for nota in note:
            id_disc = nota
            disc = self.__repo_discipline.cauta_dupa_id(id_disc)
            studenti = note[nota]
            disc_stud_dto = DiscStudDTO(disc.get_nume(), studenti)
            rezultat.append(disc_stud_dto)
        return rezultat




